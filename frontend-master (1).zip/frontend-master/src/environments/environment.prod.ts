export const environment = {
  production: true,
  apiUrl: 'http://group3-1-i.comp.nus.edu.sg:5436'
  // apiUrl: 'http://localhost:3000'
};
